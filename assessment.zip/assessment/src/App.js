import "./App.css";
import { Home, Quiz } from "./pages";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

function App() {
  return (
    <div className="App">
      <Router>
        <Routes>
          <Route path="/" element={<Home/>}/>
          <Route path="/questionnaire/:id" element={<Quiz />}/>
        </Routes>
      </Router>
    </div>
  );
}

export default App;
