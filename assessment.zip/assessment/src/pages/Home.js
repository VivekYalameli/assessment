import React from "react";
import { useNavigate } from "react-router-dom";

export default function Home(){
    const id=1;
    const navigate = useNavigate();
    const handleProceed=()=>{
        navigate("/questionnaire/:id",{state: id})
    }
    return(
        <>
        <button onClick={handleProceed} data-testid="option ">Attempt</button>
        </>
    )
}