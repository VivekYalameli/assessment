import React from "react";
import quetionBank from "../api/questionBank.json";
import { useLocation } from "react-router-dom";
import { useState, useEffect } from "react";

export default function Quiz() {
  const { state } = useLocation();
  console.log(state, quetionBank);
  const [activeQuestion, setActiveQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState(null);
  const [correct, setCorrect] = useState(null);
  const [wrong, setWrong] = useState(0);
  const [response, setResponse] = useState(false);
  const [result, setResult] = useState(0);
  const [showResult, setShowResult] = useState(false);
  const [timer, setTimer] = useState(10);

  useEffect(() => {
    let timerInterval;
    if (!showResult) {
      timerInterval = setInterval(() => {
        if (timer > 0) {
          setTimer(timer - 1);
        } else {
          if (selectedAnswer === null && !correct) {
            setWrong((prev) => prev + 1);
            handleNext();
          } else {
            console.log("anss", selectedAnswer);
            if (!response) {
              console.log("inside");
              setWrong((prev)=>prev+1)
            }
            handleNext();
          }
        }
      }, 1000);
    }
    return () => clearInterval(timerInterval);
  }, [timer, showResult]);

  const questions = quetionBank[state - 1].questionbank;
  console.log(questions, activeQuestion);

  const { Question, Option1, Option2, Answer } = questions[activeQuestion];

  const onAnswerSelected = (e) => {
    console.log(e.target.value);
    setSelectedAnswer(e.target.value);
  };

  const handleSubmit = () => {
    if (Answer == selectedAnswer) {
      setCorrect(true);
      setResponse(true);
    } else {
      console.log("else");
      setCorrect(false);
      setWrong((prev) => prev + 1);
    }
    console.log("handle", correct);
    setResponse(true);
  };

  const handleNext = () => {
    console.log("res", correct);
    setResult((prev) => (correct ? prev + 1 : prev));
    if (activeQuestion !== questions.length - 1) {
      setActiveQuestion((prev) => prev + 1);
      console.log(activeQuestion, "+++++");
    } else {
      setActiveQuestion(0);
      setShowResult(true);
      clearInterval(timer);
    }
    setCorrect(false);
    setSelectedAnswer(null);
    setResponse(false);
    setTimer(10);
  };

  // useEffect(()=>{
  //   const timerInterval = setInterval(()=>{
  //     if (timer>0){
  //       setTimer(timer-1);
  //     }else{
  //       if(selectedAnswer===null){
  //         setWrong((prev)=>prev+1)
  //         handleNext();
  //       }else{
  //         handleSubmit();
  //         handleNext();
  //       }
  //     }
  //   },1000);
  //   return ()=> clearInterval(timerInterval)
  // },[timer, showResult]);

  return (
    <div className="container" style={{ float: "left" }}>
      {!showResult ? (
        <>
          <div>
            <h1>{state}</h1>
          </div>
          <h2>Q. {Question}</h2>
          <div
            style={{
              justifyContent: "space-between",
              float: "left",
              marginLeft: "20px",
            }}
          >
            <input
              type="radio"
              onChange={onAnswerSelected}
              checked={selectedAnswer === "1"}
              value={1}
            />
            <span>{Option1}</span>
            <br />
            <input
              type="radio"
              onChange={onAnswerSelected}
              checked={selectedAnswer === "2"}
              value={2}
            />
            <span>{Option2}</span>
          </div>
          <br />
          <br />
          {response ? (
            correct ? (
              <p style={{ color: "green" }}>Your Answer is correct</p>
            ) : (
              <p style={{ color: "red" }}>Your Answer is wrong</p>
            )
          ) : (
            <></>
          )}
          <br />
          <br />
          <div className="container" style={{ display: "flex", justifyContent: "space-between" }}>
            
              <button
                className="button"
                style={{ backgroundColor: "red", color: "white" }}
                onClick={handleSubmit}
                disabled={selectedAnswer === null}
              >
                Ok
              </button>
            

              
              <button className="button" style={{backgroundColor: "red", color: "white"}} disabled={!response} onClick={handleNext}>
                Next
              </button>
            </div>
          
        </>
      ) : (
        <div>
          <h1>Thanks For attempting the test</h1>
          <br />
          <h2>Your Score is :- {result}</h2>
          <br />
          <h3>Total Correct :- {result}</h3>
          <br />
          <h3>Total Wrong :- {wrong}</h3>
        </div>
      )}
    </div>
  );
}
