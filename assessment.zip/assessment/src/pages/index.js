import Home from "./Home";
import Quiz from "./Quiz";

export {Home, Quiz};